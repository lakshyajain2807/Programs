package Strings;

public class StringThree {
    public static void main(String[] args) {
        // 1. printing the decimal point values 
        float a = 45.1234f;
        System.out.printf("Formatted number is %.2f\n", a);
        System.out.printf("The output is %.2f\n", Math.PI);
        // 2. You can also explore the list of placeholders on your own -Google it
    }
}
