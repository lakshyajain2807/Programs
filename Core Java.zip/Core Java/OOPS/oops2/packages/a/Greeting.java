package OOPS.oops2.packages.a;

public class Greeting {
    public static void main(String[] args) {
        System.out.println("Hello"); 
    }
}
// With the help of the import statment, you are able to run the java file in the same package
// Java search for all those items in the other file that are public andd not private and print the results of them
