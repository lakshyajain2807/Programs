package OOPS.oops2;

public class One {
    // 1. What are packages in java -- packages are just container/boxes of classes. They keep classes in compartments. Its a folder only
    //2. packages allow you to create same files in different folders.
    public static void main(String[] args) {
        System.out.println("Hello World");
    }

}
