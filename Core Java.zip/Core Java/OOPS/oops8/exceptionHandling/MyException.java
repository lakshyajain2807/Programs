package OOPS.oops8.exceptionHandling;

public class MyException extends Exception {

    // creating a construrctor method below
    //again go to the ExceptionHandle file and create your custom exception there
    public MyException(String message){
        super(message);
    }
    public static void main(String[] args) {
        
    }
}
