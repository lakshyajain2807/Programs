package OOPS.oops8.exceptionHandling;

public class Demo {
    public static void main(String[] args) {
        //you can also use the exception created in another file and within the same folder here
        ExceptionHandle.divide(3, 4);
    }
}
