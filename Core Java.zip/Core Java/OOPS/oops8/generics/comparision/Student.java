package OOPS.oops8.generics.comparision;

public class Student {

    int rollno;
    float marks;

    //created the student  constructor here and now making the main 
    public  Student(int rollno , float marks){
        this.rollno = rollno;
        this.marks = marks;
    }

   
}
