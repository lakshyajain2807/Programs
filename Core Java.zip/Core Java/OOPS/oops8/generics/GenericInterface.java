package OOPS.oops8.generics;

public interface GenericInterface<T> {
    void display();
}
