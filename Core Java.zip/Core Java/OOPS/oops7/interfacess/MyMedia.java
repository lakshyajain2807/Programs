package Core Java.OOPS.oops7.interfacess;

public interface MyMedia {
    void start();
    void stop();
}
