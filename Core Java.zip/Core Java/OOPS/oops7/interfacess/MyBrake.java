package Core Java.OOPS.oops7.interfacess;

public interface MyBrake {
    void brake();
}
