package Core Java.OOPS.oops7.interfacess;

public interface MyEngine {
    

    static final int PRICE = 78000;

    void start();
    void stop();
    void acc();
}
