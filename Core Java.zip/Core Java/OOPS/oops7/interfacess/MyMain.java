package OOPS.oops7.interfacess;

public class MyMain {
    public static void main(String[] args) {
        Car car = new Car();

        car.acc();
        car.start();
        car.stop();
    }
}

// We can be creating seperate classes for  the seperate functions in the interfaces
