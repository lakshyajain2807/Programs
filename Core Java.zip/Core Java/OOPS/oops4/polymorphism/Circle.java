package OOPS.oops4.polymorphism;

public class Circle {
    void area(){
        System.out.println("Area is 3.14*r*r");
    }   
}
