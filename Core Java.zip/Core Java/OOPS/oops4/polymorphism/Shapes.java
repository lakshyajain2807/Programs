package OOPS.oops4.polymorphism;

public class Shapes {
    void area(){
        System.out.println("I am in the shapes");
    }
}
