package OOPS.oops4.polymorphism;

public class Rectangle {
    // this is called annotation, just to check whether a created valid method is being overridden or not
    void area(){
        System.out.println("Area of rect is l*b");
    }
}
