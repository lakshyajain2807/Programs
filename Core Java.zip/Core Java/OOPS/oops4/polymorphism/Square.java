package OOPS.oops4.polymorphism;

public class Square {
    void area(){
        System.out.println("Area is : side *side");
    }
    
}
