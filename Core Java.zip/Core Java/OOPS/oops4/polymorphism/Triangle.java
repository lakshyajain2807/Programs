package OOPS.oops4.polymorphism;

public class Triangle {
    void area(){
        System.out.println("Area is : 0.5*l*h");
    }
}
